document.getElementById('fetchButton').addEventListener('click', fetchCryptoData);

function fetchCryptoData() {
    const apiUrl = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false';

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            displayCryptoData(data);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            document.getElementById('cryptoContainer').innerHTML = '<p style="color:red;">Failed to fetch data.</p>';
        });
}

function displayCryptoData(cryptos) {
    const cryptoContainer = document.getElementById('cryptoContainer');
    cryptoContainer.innerHTML = '';  // Clear any previous data

    cryptos.forEach(crypto => {
        const cryptoCard = document.createElement('div');
        cryptoCard.className = 'crypto-card';

        cryptoCard.innerHTML = `
            <img src="${crypto.image}" alt="${crypto.name} Logo">
            <div class="crypto-info">
                <h3>${crypto.name} (${crypto.symbol.toUpperCase()})</h3>
                <p><strong>Price:</strong> $${crypto.current_price.toLocaleString()}</p>
                <p><strong>Market Cap:</strong> $${crypto.market_cap.toLocaleString()}</p>
            </div>
        `;

        cryptoContainer.appendChild(cryptoCard);
    });
}
